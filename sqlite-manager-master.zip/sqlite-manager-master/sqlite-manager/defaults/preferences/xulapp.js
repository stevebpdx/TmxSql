pref("toolkit.defaultChromeURI", "chrome://sqlitemanager/content/sqlitemanager.xul");
pref("toolkit.defaultChromeFeatures", "chrome,resizable,centerscreen,dialog=no");
//to show js/css errors in error console
pref("javascript.options.showInConsole", true);
pref("layout.css.report_errors", true);

